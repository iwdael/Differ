package com.hacknife.differrepair;

public class DifferCore {
	static {
		System.load(System.getProperty("user.dir") + "/bsdiff.so");
	}
	
	public static native void bsdiff(String var0, String var1, String var2);
}
