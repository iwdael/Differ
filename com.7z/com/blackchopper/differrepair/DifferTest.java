package com.blackchopper.differrepair;

import com.blackchopper.differrepair.DifferCore;

public class DifferTest {
    public DifferTest() { 
    }

    public static void main(String[] argv) {
			      
	    DifferCore.bsdiff(argv[0], argv[1], argv[2]);
				    
    }
}

